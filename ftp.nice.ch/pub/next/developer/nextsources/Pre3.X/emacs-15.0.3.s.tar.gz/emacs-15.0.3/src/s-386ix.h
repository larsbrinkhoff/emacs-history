#include "s-usg5-3.h"

#define NO_SIOCTL_H

#define BROKEN_TIOCGETC
