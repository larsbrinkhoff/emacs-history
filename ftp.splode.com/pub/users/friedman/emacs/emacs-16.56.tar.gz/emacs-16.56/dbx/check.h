#ifndef check_h
#define check_h
check(/* p */);
#endif
