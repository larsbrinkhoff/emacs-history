#ifndef keywords_h
#define keywords_h
#include "scanner.h"
enterkeywords(/*  */);
keywords_free(/*  */);
String keywdstring(/* t */);
Token findkeyword(/* n */);
enter_alias(/* newcmd, oldcmd */);
print_alias(/* cmd */);
#endif
