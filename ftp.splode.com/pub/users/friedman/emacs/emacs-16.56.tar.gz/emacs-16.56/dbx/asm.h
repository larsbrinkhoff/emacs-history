#ifndef asm_h
#define asm_h
asm_init(/*  */);
Boolean asm_typematch(/* type1, type2 */);
asm_printdecl(/* s */);
asm_printval(/* s */);
#endif
