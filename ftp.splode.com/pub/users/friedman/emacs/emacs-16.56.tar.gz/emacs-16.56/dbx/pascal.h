#ifndef pascal_h
#define pascal_h
pascal_init(/*  */);
Boolean pascal_typematch(/* type1, type2 */);
pascal_printdecl(/* s */);
pascal_printval(/* s */);
#endif
