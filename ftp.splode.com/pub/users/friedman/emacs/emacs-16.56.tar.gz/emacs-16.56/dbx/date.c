char *date = "3/15/85 19:15 (mit-prep)";
