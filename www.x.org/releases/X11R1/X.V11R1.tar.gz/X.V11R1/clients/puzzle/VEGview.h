/*
 *	$Source: /orpheus/u1/X11/NRFPT/puzzle/RCS/VEGview.h,v $
 *	$Header: VEGview.h,v 1.1 87/09/08 17:27:50 swick Exp $
 */

/* Header file for VEGview */

#define YF_TYPE 8

#define STRAT_CACHE 0
#define STRAT_CACHE_ALL 1
#define STRAT_REFRESH 2

extern char *prog_name;
