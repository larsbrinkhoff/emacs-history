/* $Header: version.c,v 1.1 87/09/11 08:21:07 toddb Exp $ */
char version[] = "1.2.0 phr";
char date[] = "Fri Jul 24 22:13:58 1987";
