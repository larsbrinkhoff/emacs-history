#! /bin/sh
for i in *
do
	echo $i >> arguments
done
