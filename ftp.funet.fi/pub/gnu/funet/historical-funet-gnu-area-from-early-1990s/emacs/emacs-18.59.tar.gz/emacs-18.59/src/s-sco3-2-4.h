/* Support SCO V 3.2.4 (also called Open Desk Top 2.0) */

#include "s-sco.h"
