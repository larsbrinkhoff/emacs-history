/* s- file for Interactive (ISC) Unix version 3.0 on the 386.  */

#include "s-isc2-2.h"

/* These have been moved into s-isc2-2.h.  */
/* #define HAVE_SOCKETS
#define HAVE_SELECT */
