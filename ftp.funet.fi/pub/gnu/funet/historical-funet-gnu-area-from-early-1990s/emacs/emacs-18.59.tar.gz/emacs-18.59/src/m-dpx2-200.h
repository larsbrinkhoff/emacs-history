/* m-dpx2-200.h for DPX/2 models 210, 220, etc.  */

#define ncl_el
#include "m-dpx2.h"
