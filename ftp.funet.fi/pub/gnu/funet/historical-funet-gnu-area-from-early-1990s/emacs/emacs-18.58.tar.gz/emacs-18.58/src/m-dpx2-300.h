/* m-dpx2-300.h for DPX/2 models 320, 340, and maybe others.  */

#define ncl_mr 1
#include "m-dpx2.h"
