#include "s-bsd4-2.h"

/* Say that the text segment of a.out includes the header;
   the header actually occupies the first few bytes of the text segment
   and is counted in hdr.a_text.  */

#define O_NDELAY        FNDELAY /* Non-blocking I/O (4.2 style) */
#define LD_SWITCH_SYSTEM -e __start -Bstatic
#define SUNOS_LOCALTIME_BUG
/* A static function called by tzsetwall clears the byte just past an
 * eight byte region it mallocs.  Without this patch, that unsociable act
 * corrupts GNU malloc's memory pool.
 */

/* Allow the X Compose feature
 */
#define X_COMPOSE  
