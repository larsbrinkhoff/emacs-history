/* Source code copyright 1989 by Alan M. Carroll, all rights reserved.
 * This code may be freely distributed as long as the copyright is preserved.
 */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* set starting X-windows defaults */
static struct XDefaultEntry xdef[] =
    {
        {   (VOID *)&XD_screen.requested_geometry,XDT_String,
	    ".screen.geometry",".Screen.Geometry" },
        {   (VOID *)&XD_minibuf.requested_geometry,XDT_String,
	    ".minibuf.geometry",".Minibuf.Geometry" },

	{  (VOID *)&XD_screen.name , XDT_String,
	   ".screen.name" , ".Screen.Name" },
	{  (VOID *)&XD_screen.class , XDT_String,
	   ".screen.class" , ".Screen.Class" },
	{  (VOID *)&XD_screen.resource , XDT_String,
	   ".screen.resource" , ".Screen.Resource" },
	{  (VOID *)&XD_screen.icon_name , XDT_String,
	   ".screen.icon.name", ".Screen.Icon.Name" },
	{  (VOID *)&XD_minibuf.name , XDT_String,
	   ".minibuf.name" , ".Minibuf.Name" },
	{  (VOID *)&XD_minibuf.class , XDT_String,
	   ".minibuf.class" , ".Minibuf.Class" },
	{  (VOID *)&XD_minibuf.resource , XDT_String,
	   ".minibuf.resource" , ".Minibuf.Resource" },
	{  (VOID *)&XD_minibuf.icon_name , XDT_String,
	   ".minibuf.icon.name", ".Minibuf.Icon.Name" },

	{  (VOID *)&XD_screen.foreground,XDT_String,
	   ".screen.foreground", ".Screen.Foreground" },
	{  (VOID *)&XD_screen.background,XDT_String,
	   ".screen.background", ".Screen.Background" },
	{  (VOID *)&XD_minibuf.foreground , XDT_String,
	   ".minibuf.foreground", ".Minibuf.Foreground" },
	{  (VOID *)&XD_minibuf.background , XDT_String,
	   ".minibuf.background" , ".Minibuf.Background" },
	{  (VOID *)&XD_screen.cursor , XDT_String,
	   ".screen.cursor.color" , ".Screen.Cursor.Color" },
	{  (VOID *)&XD_minibuf.cursor , XDT_String,
	   ".minibuf.cursor.color" , ".Minibuf.Cursor.Color" },
	{  (VOID *)&XD_screen.cursor_glyph, XDT_Int,
	   ".screen.cursor.glyph" , ".Screen.Cursor.Glyph" },
	{  (VOID *)&XD_minibuf.cursor_glyph, XDT_Int,
	   ".minibuf.cursor.glyph" , ".Minibuf.Cursor.Glyph" },
	{  (VOID *)&XD_screen.xfcursor, XDT_String,
	   ".screen.cursor.foreground" , ".Screen.Cursor.Foreground" },
	{  (VOID *)&XD_minibuf.xfcursor, XDT_String,
	   ".minibuf.cursor.foreground" , ".Minibuf.Cursor.Foreground" },
	{  (VOID *)&XD_screen.xbcursor, XDT_String,
	   ".screen.cursor.background" , ".Screen.Cursor.Background" },
	{  (VOID *)&XD_minibuf.xbcursor, XDT_String,
	   ".minibuf.cursor.background" , ".Minibuf.Cursor.Background" },

	{  (VOID *)&XD_screen.color_border , XDT_String,
	   ".screen.border.color" , ".Screen.Border.Color" },
	{  (VOID *)&XD_screen.out_border , XDT_Int,
	   ".screen.border.width" , ".Screen.Border.Width" },
	{  (VOID *)&XD_screen.in_border , XDT_Int,
	   ".screen.internal.border.width" , ".Screen.Internal.Border.Width" },

	{  (VOID *)&XD_minibuf.color_border , XDT_String,
	   ".minibuf.border.color" , ".Minibuf.Border.Color" },
	{  (VOID *)&XD_minibuf.out_border , XDT_Int,
	   ".minibuf.border.width" , ".Minibuf.Border.Width" },
	{  (VOID *)&XD_minibuf.in_border , XDT_Int,
	   ".minibuf.internal.border.width" ,
	   ".Minibuf.Internal.Border.Width" },

	{  (VOID *)&XD_screen.reverse , XDT_BoolF,
	   ".screen.reverse" , ".Screen.Reverse" },
	{  (VOID *)&XD_minibuf.reverse, XDT_BoolF,
	   ".minibuf.reverse" , ".Minibuf.Reverse" },

	{  (VOID *)&XD_display_name , XDT_String ,
	   ".display" , ".Display" },

	{  (VOID *)&XD_screen.font, XDT_String,
	   ".screen.font" , ".Screen.Font" },
	{  (VOID *)&XD_minibuf.font, XDT_String,
	   ".minibuf.font" , ".Minibuf.Font" },

	{  (VOID *)&XD_screen.update_screen, XDT_BoolF,
	   ".screen.update", ".Screen.Update" },
	{  (VOID *)&XD_screen.motion_hints, XDT_BoolF,
	   ".screen.motion", ".Screen.Motion" },

    };
#define xdef_size	(sizeof(xdef)/sizeof(struct XDefaultEntry))
