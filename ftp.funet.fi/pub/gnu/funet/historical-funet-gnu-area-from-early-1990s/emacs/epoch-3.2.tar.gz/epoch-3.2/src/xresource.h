/* Source code copyright 1990 by Alan M. Carroll, all rights reserved.
 * This code may be freely distributed as long as the copyright is preserved.
 */
/* definitions for X resource ID's inside Elisp */

struct Lisp_Xresource
  {
  Lisp_Object next;	/* free list and mark bits - MUST BE FIRST! */
  XID id;
  Atom type;
  Display *dpy;				/* display resource is on */
  int plane;				/* which display plane */
  };

#define XXRESOURCE(a) ((struct Lisp_Xresource *) XPNTR(a))

extern Lisp_Object Qepoch_resourcep;
#define CHECK_XRESOURCE(x, i) \
  { if (XTYPE ((x)) != Lisp_Xresource) x = wrong_type_argument (Qepoch_resourcep, (x)); }

#define XRESOURCEP(a) (XTYPE(a) == Lisp_Xresource)

extern struct Lisp_Xresource *ResourceOrScreen();
