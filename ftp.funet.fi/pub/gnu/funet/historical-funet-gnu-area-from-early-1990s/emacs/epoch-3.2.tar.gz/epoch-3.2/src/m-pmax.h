#include "m-mips.h"
#undef LIBS_MACHINE
#undef BIG_ENDIAN
#define DATA_START 0x10000000
#define DATA_SEG_BITS 0x10000000
  









