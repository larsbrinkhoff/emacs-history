#include "s-hpux.h"
#define HPUX_7
