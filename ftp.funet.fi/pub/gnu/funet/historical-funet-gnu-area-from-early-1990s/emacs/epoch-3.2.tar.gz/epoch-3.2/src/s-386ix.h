/* file for Interactive's 386/ix */
#include "s-usg5-3.h"

#define OS_386ix

#define HAVE_TIMEVAL
#define HAVE_SELECT
#define HAVE_SOCKETS
#define HAVE_PTYS
#define SYSV_PTYS

#define USE_STREAMS

#undef LIBX11_SYSTEM
#define LIBX11_SYSTEM -linet -L/usr/local/lib -lgnu

/* inhibit 'asm' keyword in netinet/in.h */
#define NO_ASM

/* because we HAVE_TIMEVAL, some things get confused. utime() is one of
   them. This define causes utime() instead of utimes() to be used.
 */
#define USE_UTIME

/* Left overlap works, right doesn't - experimentally verified */
#define SAFE_BCOPY_RIGHT_OVERLAP 0
#define SAFE_BCOPY_LEFT_OVERLAP 1
