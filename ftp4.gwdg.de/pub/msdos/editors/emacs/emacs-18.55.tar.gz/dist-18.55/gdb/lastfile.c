/* This ends the chain of files for the purpose of initialization,
   because it does not attempt to find the start of the following file.  */

initialize_last_file ()
{
}
