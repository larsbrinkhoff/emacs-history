#include "m-mips.h"
#undef LIBS_MACHINE
#undef BIG_ENDIAN
