enum foo {foo1, foo2};

static double statdouble;

newfun (ac)
     struct haha {int a; } ac;
{
}

struct temp {int a; };

bar (a)
     enum foo a;
{
  static int lose;
  double happy;
  typedef int myint;

  {
    union wow { int a; char b; } wowvar;
    static union wow wowvar1;
    typedef int yourint;
    char *winner;
  }
}
