/* Define the current version number of GDB.  */

char *version = "2.1";
